// app/components/ImportantDates.tsx
"use client";

import { gsap } from "gsap";
import { useGSAP } from "@gsap/react";

type Props = {
  pageData: any;
};

export default function ImportantDates({ pageData }: Props) {
  useGSAP(() => {
    gsap.from(".timeline-item", {
      opacity: 0,
      y: 80,
      duration: 0.8,
      ease: "power3.out",
      stagger: 0.3,
      scrollTrigger: {
        trigger: ".timeline",
        start: "top 80%",
        scrub: true,
        end: "bottom 20%",
        toggleActions: "play none none reset",
      },
    });
  });

  return (
    <section>
      <div className="mx-auto max-w-4xl">
        <h2
          id="important-dates-heading"
          className="text-center text-3xl font-bold tracking-tight text-slate-900 md:text-4xl heading"
        >
          {pageData.importantdateheading.value}
        </h2>

        <div className="relative timeline mt-8">
          {/* Timeline line */}
          <div className="absolute left-1/2 top-0 h-full w-1 bg-slate-200 -translate-x-1/2 hidden md:block" />

          <ol className="space-y-12 md:space-y-16 relative">
            {pageData.importantdateitems.value.map(
              (item: any, index: number) => {
                const isLeft = index % 2 === 0;
                return (
                  <li
                    key={index}
                    className={`timeline-item relative flex w-full 
                      md:items-center 
                      ${isLeft ? "md:justify-start" : "md:justify-end"} 
                      justify-center`}
                  >
                    {/* Circle indicator (hidden on mobile) */}
                    <div className="absolute left-1/2 -translate-x-1/2 w-6 h-6 rounded-full bg-white border-4 border-primary-3 shadow-md z-10 hidden md:block" />

                    {/* Content box */}
                    <div
                      className={`w-full md:w-5/12 p-6 bg-white rounded-2xl shadow-md relative z-20 hover:ring-2 hover:ring-primary-3
                        ${isLeft ? "md:text-right" : "md:text-left"} text-center`}
                    >
                      <div className="flex flex-col items-center">
                        <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-slate-100 shadow-md">
                          <img
                            src={item.icon.value[0]?.url}
                            alt={item.name.value}
                            className="h-8 w-8 object-contain"
                          />
                        </div>
                        <h3 className="font-semibold text-lg text-slate-800">
                          {item.name.value}
                        </h3>
                        <p className="mt-2 text-slate-600 text-sm">
                          {item.date.value ? item.date.value : "TBA"}
                        </p>
                      </div>
                    </div>
                  </li>
                );
              }
            )}
          </ol>
        </div>
      </div>
    </section>
  );
}
